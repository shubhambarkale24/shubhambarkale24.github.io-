SHUBHAM BARKALE — PERSONAL WEBSITE
===================================

WHAT YOU HAVE
-------------
A 5-page static website. No build step, no server needed — just open or upload.

  index.html        Home / landing
  about.html        About + full achievements record
  blog.html         Writing index (list of posts)
  mentorship.html   Mentorship offering
  connect.html      Contact links
  posts/            Folder holding individual blog posts
  css/style.css     All styling (edit colours/fonts here)
  assets/           Put your photo here

THINGS TO REPLACE (search for these)
------------------------------------
1. YOUR PHOTO
   - Save a portrait as: assets/portrait.jpg
   - In index.html and about.html find the comment "Replace this block"
     and swap the placeholder <div> for:  <img src="assets/portrait.jpg" alt="Shubham Barkale">

2. CONTACT LINKS  (connect.html)
   - Email:     change mailto:hello@example.com to your address
   - X/Twitter: change href="#" to your profile URL
   - Instagram: change href="#" to your profile URL
   - LinkedIn is already set to your profile.

3. BLOG POSTS
   - A sample post lives at posts/start-here.html — replace its text with your real essay.
   - To add a post: copy that file, rename it, edit it, then add a matching
     row in blog.html (instructions are in the comments there).

HOSTING (free options)
----------------------
- GitHub Pages: create a repo, upload these files, enable Pages.
- Netlify / Cloudflare Pages: drag-and-drop this folder onto their dashboard.
- Any web host: upload the whole folder; index.html is the entry point.

For a custom domain (e.g. shubhambarkale.in), buy it and point it at whichever
host you choose — each has a one-page guide for this.
